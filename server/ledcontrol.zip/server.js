
const PORT = 8080;

var fs = require('fs');
var http = require('http');
var path = require('path');

// WebSocket handler
const dgram = require('dgram');
const WebSocket = require('ws');

var wss = new WebSocket.Server({
  noServer: true
});

wss.on('connection', function(socket) {
  const d_sock = dgram.createSocket('udp4');
  
  const scanPacket = Buffer.from("CentralLED\x00");

  d_sock.on('connect', () => {
    d_sock.send(Buffer.from('CentralLED\x02'));
  });
  
  current_ip = '';

  d_sock.on('message', (msg, rinfo) => {
    if (msg.equals(scanPacket)) {
      socket.send(JSON.stringify({
        type: 'scan-result',
        ip: rinfo.address
      }));
      return;
    }
    
    var i = 0;
    
    var n = msg[i++] << 8 | msg[i++];
    var bright = msg[i++];
    var fade = msg[i++];
    var colors = [];
    for (var x = 0; x < 3; ++x) {
      colors.push((msg[i++] != 0 ? '.' : '') + msg.subarray(i + 1, i + 1 + msg[i]).toString());
      i += 1 + msg[i];
    }
    
    socket.send(JSON.stringify({
      type: 'get',
      n: n, brightness: bright, fade: fade,
      h: colors[0], s: colors[1], v: colors[2]
    }));
  });

  socket.on('message', function(data) {
    var msg = JSON.parse(data);
    
    switch (msg.type) {
      case 'scan':
        d_sock.send(scanPacket, 55420, msg.ip);
        break;
      
      case 'set-ip':
        try {
          d_sock.disconnect();
        } catch (e) {
          // That's okay, for now?
        }
        
        //d_sock.connect(55420, msg.ip);
        current_ip = msg.ip;
        d_sock.send(Buffer.from('CentralLED\x02'), 0, 11, 55420, msg.ip);
        break;
      
      case 'set':
        var changed = 0;
        
        var payload = "";
        
        if ("bright" in msg) {
          changed |= 1;
          payload += String.fromCharCode(parseInt(msg.bright));
        }
        
        if (msg.fade) {
          changed |= 2;
          payload += String.fromCharCode(msg.fade);
        }
        
        if (msg.fade) {
          changed |= 2;
          payload += String.fromCharCode(msg.fade);
        }
        
        var options = [ "h", "s", "v" ];
        for (var i in options) {
          if (options[i] in msg && msg[options[i]].length > 0) {
            var v = msg[options[i]];
            changed |= 4 << i;
            payload += v[0] == '.' ? '\x01' : '\x00';
            payload += v[0] == '.' ? v.substring(1) : v;
            payload += '\x00';
          }
        }
        //console.log("Sending", Buffer.from('CentralLED\x01' + String.fromCharCode(changed) + payload));
        var buffer = Buffer.from('CentralLED\x01' + String.fromCharCode(changed) + payload);
        
        d_sock.send(buffer, 0, buffer.length, 55420, current_ip);
        break;
    }
  });
});

// Static file server
var server = http.createServer(function(req, res) {
  var url = req.url;
  if (url === "/")
    url = "/index.html";
  
  var resolvedBase = path.resolve('./static');
  var safeSuffix = path.normalize(url).replace(/^(\.\.[\/\\])+/, '');
  var fileLoc = path.join(resolvedBase, safeSuffix);
  
  fs.readFile(fileLoc, function(err, data) {
    if (err) {
      res.writeHead(404, 'Not Found');
      res.write('404: File Not Found!');
      return res.end();
    }
    
    res.statusCode = 200;
    res.write(data);
    
    return res.end();
  });
}).listen(PORT).on('upgrade', function upgrade(request, socket, head) {
  wss.handleUpgrade(request, socket, head, function done(ws) {
    wss.emit('connection', ws, request);
  });
});

console.log("Started listening for clients");
